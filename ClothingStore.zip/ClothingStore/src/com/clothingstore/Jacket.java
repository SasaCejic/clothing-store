package com.clothingstore;

public class Jacket extends Product{
    private int size;

    public Jacket(String name, String brand, double price, String color, int size) {
        super(name, brand, price, color);
        this.size = this.isSizeValid(size) ? size : null;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = this.isSizeValid(size) ? size : null;
    }
    
    private boolean isSizeValid(int size){
        for (int i = 42; i <= 66; i+=2) {
            if(size == i){
                return true;
            }
        }
        return false;
    }

}
