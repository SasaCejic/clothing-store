package com.clothingstore;

public class Shirt extends Product{
    private String size;

    public Shirt(String name, String brand, double price, String color, String size) {
        super(name, brand, price, color);
        this.size = isSizeValid(size) ? size : null;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = isSizeValid(size) ? size : null;
    }

    private boolean isSizeValid(String size){
        if(size.equalsIgnoreCase("XS") || size.equalsIgnoreCase("S") ||
                size.equalsIgnoreCase("M") || size.equalsIgnoreCase("L") ||
                size.equalsIgnoreCase("XL") || size.equalsIgnoreCase("2XL")){
            return true;
        }
        return false;
    }

    @Override
    public double calculateDiscount(int productsInCart, String day) {

        if(productsInCart < 3 && day.equalsIgnoreCase("tuesday")){
            return ((this.getPrice() / 100) * 10);

        }

        return super.calculateDiscount(productsInCart, day);

    }

    @Override
    public int calculateDiscountPercentage(int productsInCart, String day) {

        if(productsInCart < 3 && day.equalsIgnoreCase("tuesday")){
            return 10;

        }

        return super.calculateDiscountPercentage(productsInCart, day);

    }

}
