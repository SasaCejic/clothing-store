package com.clothingstore;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Cashier {

    public Cashier() {
    }

    public void printReceipt(Cart cart, LocalDateTime time){
        if(!cart.getProducts().isEmpty()){
            double subtotal = 0.0;
            double discountSum = 0.0;

            DateTimeFormatter formatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedDate = time.format(formatObj);

            System.out.println("Date: " + formattedDate);
            System.out.println("--Products--");
            System.out.println();

            for (int i = 0; i < cart.getProducts().size(); i++) {

                Product product = cart.getProducts().get(i);

                System.out.println(product.getName() + " - " + product.getBrand());
                System.out.println("$" + product.getPrice());
                subtotal += product.getPrice();

                if(product.calculateDiscountPercentage(cart.getProducts().size(), time.getDayOfWeek().toString()) > 0){
                    System.out.print("#discount " + product.calculateDiscountPercentage(cart.getProducts().size(), time.getDayOfWeek().toString()) + "%");
                    System.out.printf(" -$%.2f", product.calculateDiscount(cart.getProducts().size(), time.getDayOfWeek().toString()));

                    System.out.println();


                    discountSum += product.calculateDiscount(cart.getProducts().size(), time.getDayOfWeek().toString());
                }

                System.out.println();
            }

            System.out.println("----------------------------------------");
            System.out.println("SUBTOTAL: $" + subtotal);
            System.out.print("DISCOUNT: -$");
            System.out.printf("%.2f", discountSum);
            System.out.println();
            System.out.printf("TOTAL: $%.2f" , (subtotal - discountSum));

        }else{
            System.out.println("The cart is empty!");
        }
    }
}
