package com.clothingstore;

public interface DiscountInterface {

    double calculateDiscount(int productsInCart, String day);

    int calculateDiscountPercentage(int productsInCart, String day);

}
