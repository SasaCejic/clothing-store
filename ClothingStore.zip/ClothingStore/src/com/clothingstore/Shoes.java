package com.clothingstore;


public class Shoes extends Product{
    private int size;

    public Shoes(String name, String brand, double price, String color, int size) {
        super(name, brand, price, color);
        this.size = this.isSizeValid(size) ? size : null;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = this.isSizeValid(size) ? size : null;
    }

    private boolean isSizeValid(int size){
        if(size >= 39 && size <= 46){
            return true;
        }
        return false;
    }



    @Override
    public double calculateDiscount(int productsInCart, String day) {

        if(day.equalsIgnoreCase("tuesday")){
            return ((this.getPrice() / 100) * 25);
        }

        return super.calculateDiscount(productsInCart, day);

    }

    @Override
    public int calculateDiscountPercentage(int productsInCart, String day) {

        if(day.equalsIgnoreCase("tuesday")){
            return 25;
        }

        return super.calculateDiscountPercentage(productsInCart, day);
    }

}
