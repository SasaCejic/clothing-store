package com.clothingstore;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<Product> products;

    public Cart() {
        this.products = new ArrayList<Product>();
    }

    public List<Product> getProducts() {
        return products;
    }

    public void addProduct(Product product){
        if(!this.products.contains(product)){
            this.products.add(product);
        }
    }

    public void emptyTheCart(){
        this.products.clear();
    }

    public void removeProduct(Product product){
        if(this.products.contains(product)){
            this.products.remove(product);
        }
    }
}
