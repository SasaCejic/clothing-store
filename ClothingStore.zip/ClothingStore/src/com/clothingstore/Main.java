package com.clothingstore;

import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {

        //EXAMPLE #1

        Cart cart1 = new Cart();

        Shirt blueCotton = new Shirt("Blue Cotton Shirt", "BrandS", 14.99, "blue", "M");
        Shirt whiteCotton = new Shirt("White Cotton Shirt", "BrandS", 15.99, "white", "M");
        Trousers blackCotton = new Trousers("Black Cotton Trousers", "BrandT", 29.99, "black", 50);
        Shoes blackLeather = new Shoes("Black Leather Shoes", "BrandS", 59.99, "black", 43);
        Jacket blackCottonSuit = new Jacket("Black Cotton Suit Jacket", "BrandJ", 99.99, "black", 50);

        cart1.addProduct(blueCotton);
        cart1.addProduct(whiteCotton);
        cart1.addProduct(blackCotton);
        cart1.addProduct(blackLeather);
        cart1.addProduct(blackCottonSuit);


        Cashier cashier1 = new Cashier();

        System.out.println("EXAMPLE #1");
        System.out.println();

        cashier1.printReceipt(cart1,LocalDateTime.of(2022,2,2,12,34,56));


        //EXAMPLE #2

        Cart cart2 = new Cart();

        Shirt blackSilk = new Shirt("Black Silk Shirt", "BrandS", 29.99, "black", "L");
        Shirt whiteSilk = new Shirt("White Silk Shirt", "BrandS", 29.99, "white", "L");

        cart2.addProduct(blackSilk);
        cart2.addProduct(whiteSilk);

        Cashier cashier2 = new Cashier();

        System.out.println();
        System.out.println();
        System.out.println("EXAMPLE #2");
        System.out.println();

        cashier2.printReceipt(cart2, LocalDateTime.of(2022, 2, 1, 12, 34, 56));



        //EXAMPLE #3

        Cart cart3 = new Cart();

        Trousers redLinen = new Trousers("Red Linen Trousers", "BrandT", 49.99, "red", 56);
        Shoes redSuede = new Shoes("Red Suede Shoes", "BrandS", 59.99, "red", 44);
        Shoes blackSuede = new Shoes("Black Suede Shoes", "BrandS", 59.99, "black", 44);
        Jacket redLinenSuit = new Jacket("Red Linen Suit Jacket", "BrandJ", 99.99, "red", 56);
        Shirt whiteLinen = new Shirt("White Linen Shirt", "BrandS", 29.99, "white", "L");

        cart3.addProduct(redLinen);
        cart3.addProduct(redSuede);
        cart3.addProduct(blackSuede);
        cart3.addProduct(redLinenSuit);
        cart3.addProduct(whiteLinen);


        Cashier cashier3 = new Cashier();

        System.out.println();
        System.out.println();
        System.out.println("EXAMPLE #3");
        System.out.println();

        cashier3.printReceipt(cart3,LocalDateTime.of(2022, 2, 1, 12, 34, 56));


    }
}
